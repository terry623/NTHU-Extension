import { getCourseInfo } from "./api";
import { translateTopic, sort_weekday, addSpace_course_no } from "./helper";
import { checkConflict } from "./conflict";
var request = require("request");
const baseURL = `http://nthucourse-env.vvj7ipe3ws.us-east-1.elasticbeanstalk.com/api/`;
// const baseURL = `http://192.168.99.100/api/`;
// const baseURL = `localhost:80/api/`;

function renderSearchResult(hits, callback) {
  let page_num_content = ``;
  let all_page = Math.ceil(hits.length / 10.0);
  for (let i = 1; i < all_page; i++) {
    let page_num = i + 1;
    page_num_content = page_num_content.concat(
      `<a class="page item">` + page_num + `</a>`
    );
  }
  let change_page =
    `<a class="icon item">
    <i class="left chevron icon"></i></a>
    <a class="page active item">1</a>` +
    page_num_content +
    `<a class="icon item">
      <i class="right chevron icon"></i>
    </a>`;
  $("#search_page_change").empty();
  $("#search_page_change").append(change_page);

  storeCourseInfo(hits);
  for (let each_course in hits) {
    let id = hits[each_course]._id;
    let source = hits[each_course]._source;

    let time = source.時間;
    if (time.length == 0) time.push("無");
    sort_weekday(time);
    let classroom = source.教室;
    if (classroom.length == 0) classroom.push("無");

    checkConflict(time, function(negative) {
      let row =
        `<tr ` +
        negative +
        ` id="` +
        id +
        `">
      <td>` +
        source.科號 +
        `</td>
          <td>` +
        source.課程中文名稱 +
        `</td>
        <td>` +
        time +
        `</td>
        <td>` +
        classroom.join("<br/>") +
        `</td>
        <td>`;

      let teacher = [];
      for (let each_teacher in source.教師)
        teacher.push(source.教師[each_teacher].split("\t")[0]);
      teacher.splice(-1, 1);
      row += teacher.join("<br>") + `</td></tr>`;
      $("#search_result_body").append(row);
      $("#search_result_body > tr")
        .filter(function(index) {
          return index >= 10;
        })
        .hide();
      $("#search_result_body > tr").hover(function() {
        $(this).css("cursor", "pointer");
      });
    });
  }
  callback();
}

function searchOnlyKeyword(search_topic, keyword, callback) {
  request.post(
    {
      url: baseURL + "searchOnlyKeyword",
      form: {
        search_topic: search_topic,
        keyword: keyword
      }
    },
    function(err, response, body) {
      if (!err && response.statusCode == 200) {
        let resp = JSON.parse(body);
        let hits = resp.hits.hits;
        // console.log(hits);
        renderSearchResult(hits, callback);
      }
    }
  );
}

function searchDoubleKeyword(search_topic, keyword, other_keyword, callback) {
  request.post(
    {
      url: baseURL + "searchDoubleKeyword",
      form: {
        search_topic: search_topic,
        keyword: keyword,
        other_keyword: other_keyword
      }
    },
    function(err, response, body) {
      if (!err && response.statusCode == 200) {
        let resp = JSON.parse(body);
        let hits = resp.hits.hits;
        // console.log(hits);
        renderSearchResult(hits, callback);
      }
    }
  );
}

function searchTime(search_topic, keyword, time_group, callback) {
  console.log(time_group);
  request.post(
    {
      url: baseURL + "searchTime",
      form: {
        search_topic: search_topic,
        keyword: keyword,
        time_group: JSON.stringify(time_group)
      }
    },
    function(err, response, body) {
      if (!err && response.statusCode == 200) {
        let resp = JSON.parse(body);
        let hits = resp.hits.hits;
        // console.log(hits);
        renderSearchResult(hits, callback);
      }
    }
  );
}

function searchByKeyword(acix, keyword, other_keyword, topic, callback) {
  $("#search_result_body").empty();
  $("#search_loading").addClass("active");
  let search_topic = translateTopic(topic);

  if (other_keyword == "NoNeedToChoose") {
    console.log("search_topic:", search_topic);
    console.log("keyword:", keyword);
    searchOnlyKeyword(search_topic, keyword, callback);
  } else {
    console.log("search_topic:", search_topic);
    console.log("keyword:", keyword);
    console.log("other_keyword:", other_keyword);
    if (search_topic == "時間")
      searchTime(search_topic, keyword, other_keyword, callback);
    else searchDoubleKeyword(search_topic, keyword, other_keyword, callback);
  }
}

function storeCourseInfo(hits, callback) {
  chrome.storage.local.get("course", function(items) {
    var temp = {};
    var data = {};
    for (var each_course in hits) {
      var each = hits[each_course];
      var source = each._source;
      data[each._id] = {
        不可加簽說明: source.不可加簽說明,
        人限: source.人限,
        備註: source.備註,
        學分數: source.學分數,
        授課語言: source.授課語言,
        擋修說明: source.擋修說明,
        新生保留人數: source.新生保留人數,
        科號: source.科號,
        課程中文名稱: source.課程中文名稱,
        課程英文名稱: source.課程英文名稱,
        課程限制說明: source.課程限制說明,
        通識對象: source.通識對象,
        通識類別: source.通識類別,
        開課代碼: source.開課代碼,
        教師: source.教師,
        教室: source.教室,
        時間: source.時間,
        學程: source.學程,
        必選修: source.必選修,
        第一二專長: source.第一二專長,
        相似課程: []
      };
    }

    if (items.course != undefined) {
      Object.assign(temp, items.course);
      for (var each_data in data) {
        if (!temp.hasOwnProperty(each_data)) {
          temp[each_data] = data[each_data];
        }
      }
      chrome.storage.local.remove("course", function() {
        chrome.storage.local.set({ course: temp }, function() {
          chrome.storage.local.get("course", function(items) {
            // console.log(items);
            if (callback) callback();
          });
        });
      });
    } else {
      for (var each_data in data) temp[each_data] = data[each_data];
      chrome.storage.local.set({ course: temp }, function() {
        chrome.storage.local.get("course", function(items) {
          // console.log(items);
          if (callback) callback();
        });
      });
    }
  });
}

function searchBySingleCourseNo(course_no, callback) {
  let new_course_no = addSpace_course_no(course_no);
  request.post(
    {
      url: baseURL + "searchBySingleCourseNo",
      form: {
        course_no: new_course_no
      }
    },
    function(err, response, body) {
      if (!err && response.statusCode == 200) {
        let resp = JSON.parse(body);
        let hits = resp.hits.hits;
        callback(hits);
      }
    }
  );
}

function searchByID_Group(id_group, callback) {
  request.post(
    {
      url: baseURL + "searchByID_Group",
      form: {
        id_0: id_group[0].other_id,
        id_1: id_group[1].other_id,
        id_2: id_group[2].other_id
      }
    },
    function(err, response, body) {
      if (!err && response.statusCode == 200) {
        let resp = JSON.parse(body);
        let hits = resp.hits.hits;
        callback(hits);
      }
    }
  );
}

function dependOnType(topic) {
  $(".other_entry").hide();
  $(".ui.dropdown.search_entry_item").dropdown("clear");
  if (topic == "上課時間") $("#time_select_entry").show();
  else if (topic == "通識對象") $("#ge_people_entry").show();
  else if (topic == "通識類別") $("#ge_type_select_entry").show();
  else if (topic == "系必選修") $("#dept_entry").show();
  else if (topic == "學分學程") $("#program_entry").show();
  else if (topic == "第一二專長") $("#skill_entry").show();
  else $("#main_other_entry").show();
}

function clickToSearch(acix) {
  let topic = $("#topic_name").text();
  let keyword = $("#keyword").val();
  let other_keyword = "NoNeedToChoose";
  if (topic == "上課時間") {
    other_keyword = $("#time_select_text").val();
  } else if (topic == "通識對象") {
    other_keyword = $("#ge_people_text").val();
  } else if (topic == "通識類別") {
    other_keyword = $("#ge_type_select_text").val();
  } else if (topic == "系必選修") {
    other_keyword = $("#dept_entry_text").val();
  } else if (topic == "學分學程") {
    other_keyword = $("#program_entry_text").val();
  } else if (topic == "第一二專長") {
    other_keyword = $("#skill_entry_text").val();
  }

  if (other_keyword == "") {
    $("#search_alert_otherkeyword_empty").modal("show");
    return;
  } else if (other_keyword == "NoNeedToChoose") {
    if ($("#keyword").val() == "") {
      $("#search_alert_keyword_empty").modal("show");
      return;
    }
  }
  searchByKeyword(acix, keyword, other_keyword, topic, function() {
    $("#search_loading").removeClass("active");
    $("#search_result_page").show();
  });
  $("#search_page_change > a").removeClass("active");
  $("#search_page_change > a:nth-child(2)").addClass("active");
}

export {
  clickToSearch,
  searchBySingleCourseNo,
  storeCourseInfo,
  searchByID_Group,
  dependOnType,
  baseURL
};
