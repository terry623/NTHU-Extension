import { main } from "./data";

// setTimeout(function() {
//   change();
// }, 10000);

// function change() {
//   console.log("Change...");
//   var document = window.frames[2]["document"];
//   $("body", document).append(main);
// }
